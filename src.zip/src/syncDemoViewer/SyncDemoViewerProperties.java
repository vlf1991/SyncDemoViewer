package syncDemoViewer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.swing.JOptionPane;

public class SyncDemoViewerProperties extends Properties {

	private static final long serialVersionUID = -5517680220835665647L;

	public final static String PROPERTIES_FILE_NAME = "sync_demo_viewer.properties";

	private SyncDemoViewerProperties() {
	}

	public static SyncDemoViewerProperties getProperties() {
		try {

			File prop_file = new File("./" + PROPERTIES_FILE_NAME);
			SyncDemoViewerProperties properties;
			properties = createDefault();
			if (!prop_file.exists()) {

				BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(prop_file));
				properties.store(bos, "");
				bos.close();

				return null;
			}
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(prop_file));
			properties.load(bis);
			bis.close();

			if (properties.getCSDirectory().endsWith("e"))
				properties.put("cs_dir", properties.getCSDirectory() + "/");

			if (!new File(properties.getCSDirectory()).exists()) {
				throw new Exception(
						properties.getCSDirectory() + " directory does not exist. Check your .properties file.");
			}

			return properties;

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			throw new Error(e);
		}
	}

	private static SyncDemoViewerProperties createDefault() {
		SyncDemoViewerProperties p = new SyncDemoViewerProperties();
		p.setProperty("name", "Inspector Boris");
		p.setProperty("cs_dir", "path/to/Counter-Strike Global Offensive/");
		p.setProperty("port", "27099");
		p.setProperty("sync_interval", "100");
		p.setProperty("sync_duration", "5");
		p.setProperty("sync_key", "i");
		p.setProperty("resume_demo_key", "j");
		p.setProperty("share_pos_key", "k");
		p.setProperty("share_tick_key", "l");
		p.setProperty("exchange_key", "-");
		return p;
	}

	public int getPort() {
		return Integer.parseInt(getProperty("port"));
	}

	public char getSyncKey() {
		return getProperty("sync_key").charAt(0);
	}

	public char getExchangeKey() {
		return getProperty("exchange_key").charAt(0);
	}

	public char getSharePosKey() {
		return getProperty("share_pos_key").charAt(0);
	}

	public char getShareTickKey() {
		return getProperty("share_tick_key").charAt(0);
	}

	public char getResumeDemoKey() {
		return getProperty("resume_demo_key").charAt(0);
	}

	public int getSyncInterval() {
		return Integer.parseInt(getProperty("sync_interval"));
	}

	public int getSyncDuration() {
		return Integer.parseInt(getProperty("sync_duration"));
	}

	public String getName() {
		return getProperty("name");
	}

	public String getCSDirectory() {
		return getProperty("cs_dir");
	}

	public String getCSGODir() {
		return getCSDirectory() + "csgo/";
	}
}
