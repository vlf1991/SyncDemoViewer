package syncDemoViewer;

import java.awt.CardLayout;
import java.awt.Dimension;
import javax.swing.*;

import static javax.swing.SpringLayout.*;

public class GUI {

	private final String connection_view = "connection", client_view = "client";

	private Controller controller;

	private JFrame frame;
	private JPanel panels;
	private CardLayout cardLayout;

	private JPanel connect_panel;
	private JButton button_host, button_connect;
	private JLabel ip_label, port_label;
	private JTextField ip_field, port_field;

	private JPanel client_panel;
	private JTextArea log;
	private JScrollPane log_scroll_pane;
	private JList<String> connected_users;
	private DefaultListModel<String> list_model;
	private JButton disconnect;
	private JLabel log_label, client_list_label, status_label;

	public GUI() {
		SwingUtilities.invokeLater(() -> {
			initializeGUI();
		});
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}

	protected void initializeGUI() {
		frame = new JFrame("Sync Demo Viewer");
		cardLayout = new CardLayout();
		panels = new JPanel(cardLayout);

		// Connect Panel
		connect_panel = new JPanel();
		SpringLayout layout = new SpringLayout();
		connect_panel.setBorder(BorderFactory.createEtchedBorder());
		connect_panel.setLayout(layout);
		connect_panel.setPreferredSize(new Dimension(240, 160));

		ip_label = new JLabel("IP:");
		layout.putConstraint(SpringLayout.WEST, ip_label, 16, SpringLayout.WEST, connect_panel);
		layout.putConstraint(SpringLayout.NORTH, ip_label, 32, SpringLayout.NORTH, connect_panel);
		connect_panel.add(ip_label);

		ip_field = new JTextField();
		layout.putConstraint(SpringLayout.WEST, ip_field, 16, SpringLayout.EAST, ip_label);
		layout.putConstraint(SpringLayout.EAST, ip_field, -16, SpringLayout.EAST, connect_panel);
		layout.putConstraint(SpringLayout.NORTH, ip_field, 0, SpringLayout.NORTH, ip_label);
		connect_panel.add(ip_field);

		port_label = new JLabel("Port:");
		layout.putConstraint(SpringLayout.WEST, port_label, 16, SpringLayout.WEST, connect_panel);
		layout.putConstraint(SpringLayout.NORTH, port_label, 16, SpringLayout.SOUTH, ip_label);
		connect_panel.add(port_label);

		port_field = new JTextField();
		layout.putConstraint(SpringLayout.WEST, port_field, 0, SpringLayout.WEST, ip_field);
		layout.putConstraint(SpringLayout.EAST, port_field, -16, SpringLayout.EAST, connect_panel);
		layout.putConstraint(SpringLayout.NORTH, port_field, 0, SpringLayout.NORTH, port_label);
		connect_panel.add(port_field);

		button_connect = new JButton("Connect");
		button_connect.addActionListener(e -> controller.connect(ip_field.getText(), port_field.getText()));
		layout.putConstraint(SpringLayout.WEST, button_connect, 16, SpringLayout.WEST, connect_panel);
		layout.putConstraint(SpringLayout.NORTH, button_connect, 16, SpringLayout.SOUTH, port_field);
		connect_panel.add(button_connect);

		button_host = new JButton("Host");
		button_host.addActionListener(e -> controller.startHosting());
		layout.putConstraint(SpringLayout.NORTH, button_host, 0, SpringLayout.NORTH, button_connect);
		layout.putConstraint(SpringLayout.WEST, button_host, 16, SpringLayout.EAST, button_connect);
		connect_panel.add(button_host);

		// Client Panel
		client_panel = new JPanel();
		layout = new SpringLayout();
		client_panel.setBorder(BorderFactory.createEtchedBorder());
		client_panel.setLayout(layout);
		client_panel.setPreferredSize(new Dimension(320, 320));

		client_list_label = new JLabel("Connected clients");
		layout.putConstraint(NORTH, client_list_label, 32, NORTH, client_panel);
		layout.putConstraint(WEST, client_list_label, 16, WEST, client_panel);
		client_panel.add(client_list_label);

		disconnect = new JButton();
		layout.putConstraint(SOUTH, disconnect, -16, SOUTH, client_panel);
		layout.putConstraint(WEST, disconnect, 16, WEST, client_panel);
		disconnect.addActionListener(e -> {
			controller.disconnectOrShutdown();
		});
		client_panel.add(disconnect);

		status_label = new JLabel();
		layout.putConstraint(SOUTH, status_label, -16, SOUTH, client_panel);
		layout.putConstraint(EAST, status_label, -16, EAST, client_panel);
		client_panel.add(status_label);

		list_model = new DefaultListModel<>();
		connected_users = new JList<>(list_model);
		layout.putConstraint(NORTH, connected_users, 4, SOUTH, client_list_label);
		layout.putConstraint(WEST, connected_users, 0, WEST, client_list_label);
		layout.putConstraint(EAST, connected_users, 128, WEST, connected_users);
		layout.putConstraint(SOUTH, connected_users, -16, NORTH, disconnect);
		client_panel.add(connected_users);

		log_label = new JLabel("Log");
		layout.putConstraint(WEST, log_label, 16, EAST, connected_users);
		layout.putConstraint(NORTH, log_label, 0, NORTH, client_list_label);
		client_panel.add(log_label);

		log = new JTextArea();
		log_scroll_pane = new JScrollPane(log);
		layout.putConstraint(NORTH, log_scroll_pane, 0, NORTH, connected_users);
		layout.putConstraint(WEST, log_scroll_pane, 0, WEST, log_label);
		layout.putConstraint(EAST, log_scroll_pane, -16, EAST, client_panel);
		layout.putConstraint(SOUTH, log_scroll_pane, 0, SOUTH, connected_users);
		client_panel.add(log_scroll_pane);

		panels.add(connect_panel, connection_view);
		panels.add(client_panel, client_view);
		cardLayout.show(panels, connection_view);
		frame.add(panels);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public void showError(String message) {
		JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
	}

	public void openClientView(boolean isHost, String host, int ip) {
		list_model.clear();
		if (isHost) {
			status_label.setText("Hosting on port " + String.valueOf(ip));
			disconnect.setText("Shutdown host");
		} else {
			status_label.setText("Connected to  " + host + ":" + String.valueOf(ip));
			disconnect.setText("Disconnect");
		}
		cardLayout.show(panels, client_view);
		panels.setSize(client_panel.getPreferredSize());
		// frame.pack();
	}

	public void openConnectionView() {
		cardLayout.show(panels, connection_view);
		panels.setSize(connect_panel.getPreferredSize());
		// frame.pack();
	}

	public void addClientToList(String name) {
		list_model.addElement(name);
	}

	public void removeClientFromList(String name) {
		list_model.removeElement(name);
	}

	public void log(String message) {
		log.setText(log.getText() + message + "\n");
	}

	public void removeAllClientsFromList() {
		list_model.clear();
	}

	public void clearLog() {
		log.setText("");
	}
}
