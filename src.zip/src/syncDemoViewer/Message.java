package syncDemoViewer;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public enum Message {

	start("START"), pos("POS"), tick("TICK");

	public final static String stop_spam_response_file_name = "sync_demo_synchronization_done",
			start_spam_request_file_name = "sync_demo_synchronization_start",
			delete_old_message_file_name = "sync_demo_delete_old_message",
			message_from_cs_file_name = "sync_demo_message_from_cs",

	message_to_cs_file_name = "cfg/sync_demo_message_to_cs.cfg";

	public static void writeMessageToCs(SyncDemoViewerProperties properties, ArrayList<String> message)
			throws IOException {
		File f = new File(properties.getCSGODir() + message_to_cs_file_name);
		f.delete();
		PrintWriter writer = new PrintWriter(f);
		for (String s : message)
			writer.println(s);
		writer.close();
	}

	private String message;

	Message(String s) {
		message = s;
	}

	public String getMessage() {
		return message;
	}
}
